Shop Store theme ! Free Woocommerce Theme 
========================================
<br/>
<h4><a href="https://athemeart.com/demo/shopstore/" target="_blank">Live Demo 1</a>  |    <a href="https://athemeart.com/demo/shopstore2nd/" target="_blank">Live Demo 2 </a>     | <a href="https://athemeart.com/downloads/shopstore/" target="_blank">Documentation</a>  | <a href="https://athemeart.com/blog/docs/ecommerce-theme-user-guide/" target="_blank">PRO VERSION</a></h4>
<br/>
<a href="https://athemeart.com/downloads/shopstore/" target="_blank">
<img src="https://raw.githubusercontent.com/edatastyle/Shopstore-free-woocomerce-theme/master/screenshot.png" alt="WordPress eCommerce theme" /></a>


Here is a modern, unique, and hugely attractive Free <a href="https://athemeart.com/downloads/shopstore/" target="_blank">WordPress eCommerce theme</a> named by Shopstore. It designs with complete responsiveness to look your site extraordinary on any devices or screens. Also, its gorgeous design and mind-blowing product presentation options will make you think about how powerful and useful the theme is among other online shops. However, this type of Shopstore free <a href="https://wordpress.org/themes/shopstore/" target="_blank">WordPress store theme</a> is perfect for eCommerce websites, and best suitable for fashion, sport, technology, fashion, furniture, digitals, and any associated websites. To clarify, Shopstore is wrap up with a vast collection of customization options that are reasonably easy to use. Besides, it runs accordingly with Gutenberg and with the most popular page builders. Such as WPBakery Page Builder, Elementor, Brizy, Beaver Builder, Visual Composer, SiteOrigin, Divi, and so on. And top of that, this theme has a great friendship with Elementor and WooCommerce. So, what are you looking for, a Multi-Purpose theme, or a <strong>WordPress Store<strong>? Don't waste your valuable time searching elsewhere. Check out our unique <a href="https://athemeart.com/demo/shopstore/" rel="nofollow">demos</a> to understand, it's the only reliable, desirable, and most useful theme you always wanted.


<pre>
== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.
</pre>

<pre>
== Credits ==

Underscores:
Author: 2012-2015 Automattic
Source: http://underscores.me
License: GPLv3 or later](https://www.gnu.org/licenses/gpl-3.0.html)

Bootstrap:
Author: Twitter
Source: http://getbootstrap.com
License: Licensed under the MIT license

Fontawesome :
Author: fontawesome
Source: http://fontawesome.io/
License: [MIT/SIL OFL Licensed](http://fontawesome.io/license/)

Customizer:
Author: https://github.com/justintadlock
Source: https://github.com/justintadlock/trt-customizer-pro
License: GNU GPL

Owl Carousel 2:
Author: David Deutsch
Source: https://github.com/OwlCarousel2/OwlCarousel2
License: [MIT License.]

Tether:
Author: TrevorBurnham  
Source: https://github.com/HubSpot/tether
License: [GPLv2 or later]

RD Navbar :
Author:  OXAYAZA    
Source: https://github.com/ZemezPlugins/rd-navbar
License: GPLv2 or later

Tgmpluginactivation:
Source: http://tgmpluginactivation.com/
License: GPL-2.0 or later license.

jquery.customSelect:
Author:  Adam Coulombe    
Source: http://adam.co/lab/jquery/customselect/
License: GPL2

magnific-popup:
Author:  dimsemenov    
Source: https://github.com/dimsemenov/Magnific-Popup/blob/master/LICENSE
License: MIT License


== Google Fonts ==
Nunito
Source: https://fonts.google.com/specimen/Nunito
License: Open Font License 

Open+Sans
Source: https://fonts.google.com/specimen/Open+Sans
License: Apache License, Version 2.0  

Roboto Condensed
Source: https://fonts.google.com/specimen/Roboto+Condensed
License: Apache License, Version 2.0 

== Image Used ==
https://pxhere.com/en/photo/1451201
All are Licensed under CC0

</pre>


<pre>
== Upgrade Notice  ==

= 4.1.9 =
* Elementor editor simplify

= 4.1.8 =
* Author URL remove from footer

= 4.1.7 =
* Removed esc_attr error

= 4.1.5 =
* Removed all demo content
* theme meta info added

= 4.1.4 =
* Widget add for Advanced Product Search 

= 4.1.3 =
* stripe input box css added

= 4.1.1 =
* skip links
* keyboard navigation

= 4.1.0 =
* gutenberg gallery slider
* google font sawp
* recommed seo plugins
</pre>

<pre>
== Copyright ==
shopstore WordPress Theme, Copyright (C) 2017 aThemeArt.com
shopstore is distributed under the terms of the GNU GPL
</pre>
